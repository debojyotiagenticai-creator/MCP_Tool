"""KAF tool class for IT incident triage and runbook recommendation.

Advisory only: the tools read incident data and recommend what to do. They never change
anything. A recommendation that needs a change request comes back as an unsubmitted draft.

Everything lives in this one file on purpose (standard library only), so it works whether
KAF copies one file or the whole folder into the image.

Environment:
    INCIDENT_DATA_DIR  folder with incident.db and runbooks/*.json (default ../data)
    AUDIT_LOG          JSONL audit trail (default /tmp/incident-audit.log)
"""
from __future__ import annotations

import json
import math
import os
import re
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    from loguru import logger
except ImportError:  # local runs without loguru
    import logging
    logger = logging.getLogger(__name__)
    logger.success = logger.info  # type: ignore[attr-defined]

# --------------------------------------------------------------------------- configuration
NOW = datetime(2026, 3, 14, 2, 10)          # fixed demo clock for all incident logic (audit stamps use real time)
SLA_MINUTES = {"P1": 60, "P2": 240, "P3": 480, "P4": 1440}
PRIORITY_RANK = {"P1": 1, "P2": 2, "P3": 3, "P4": 4}
W = dict(match=0.40, history=0.30, change=0.20, service=0.10)   # confidence weights
K = 6.0                                     # text-match saturation: raw / (raw + K)
ESCALATE_BELOW = 0.35                       # below this confidence we escalate
APPROVER = "Duty Manager"
MAX_LIST = 20
STOP = set("a an and are as at be by for from has in is it of on or that the this to was with "
           "after over under about not no".split())


class _ToolError(Exception):
    """A user-facing error: the message is meant to be read by the calling agent."""


# --------------------------------------------------------------------------- paths, audit
def _data_dir() -> Path:
    env = os.environ.get("INCIDENT_DATA_DIR")
    if env:
        return Path(env)
    here = Path(__file__).resolve().parent
    for cand in (here.parent / "data", here / "data"):
        if (cand / "incident.db").exists():
            return cand
    return here.parent / "data"


def _audit(tool: str, args: dict, status: str, started: float) -> None:
    try:
        path = Path(os.environ.get("AUDIT_LOG", "/tmp/incident-audit.log"))
        rec = {"ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "tool": tool,
               "args": args, "status": status, "ms": round((time.time() - started) * 1000)}
        with path.open("a") as fh:
            fh.write(json.dumps(rec, default=str) + "\n")
    except Exception:  # auditing is best effort and must never break a tool
        pass


# --------------------------------------------------------------------------- data access
def _connect() -> sqlite3.Connection:
    path = _data_dir() / "incident.db"
    if not path.exists():
        raise _ToolError(f"Incident data not found at {path}. Run seed/seed.py to create it.")
    return sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True)   # read-only


def _rows(con: sqlite3.Connection, sql: str, args: tuple = ()) -> list[dict]:
    cur = con.execute(sql, args)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _minutes(delta: timedelta) -> int:
    return int(round(delta.total_seconds() / 60))


def _norm_id(value: Any) -> str:
    return str(value or "").strip().upper()


def _incident(con: sqlite3.Connection, incident_id: str) -> dict | None:
    rows = _rows(con, "SELECT * FROM incidents WHERE id = ?", (incident_id,))
    if not rows:
        return None
    inc = rows[0]
    inc["opened_at"] = datetime.fromisoformat(inc["opened_at"])
    return inc


def _open_ids(con: sqlite3.Connection) -> list[str]:
    return [r["id"] for r in _rows(con, "SELECT id FROM incidents WHERE status = 'open' ORDER BY id")]


def _need_incident(con: sqlite3.Connection, raw_id: Any) -> dict:
    iid = _norm_id(raw_id)
    if not iid:
        raise _ToolError("incident_id is required, for example INC0101. "
                         f"Open incidents: {', '.join(_open_ids(con))}")
    inc = _incident(con, iid)
    if inc is None:
        raise _ToolError(f"Unknown incident '{iid}'. Open incidents: {', '.join(_open_ids(con))}")
    return inc


def _changes(con: sqlite3.Connection) -> list[dict]:
    rows = _rows(con, "SELECT id, ci, service, description, deployed_at, change_type "
                      "FROM changes ORDER BY deployed_at DESC")
    for r in rows:
        r["deployed_at"] = datetime.fromisoformat(r["deployed_at"])
    return rows


def _history(con: sqlite3.Connection) -> list[dict]:
    return _rows(con, "SELECT id, summary, description, resolution_runbook, resolution_notes "
                      "FROM incidents WHERE status = 'resolved' ORDER BY id")


def _runbooks() -> list[dict]:
    folder = _data_dir() / "runbooks"
    out = []
    for path in sorted(folder.glob("*.json")):
        rb = json.loads(path.read_text())
        rb["steps_text"] = " ".join(s["text"] for s in rb["steps"])
        out.append(rb)
    if not out:
        raise _ToolError(f"No runbooks found in {folder}.")
    return out


def _sla_remaining(inc: dict) -> int:
    due = inc["opened_at"] + timedelta(minutes=SLA_MINUTES.get(inc["priority"], 1440))
    return _minutes(due - NOW)


def _sla_state(inc: dict) -> str:
    remaining, total = _sla_remaining(inc), SLA_MINUTES.get(inc["priority"], 1440)
    return "breached" if remaining < 0 else "at_risk" if remaining < 0.25 * total else "ok"


def _age_text(minutes: int) -> str:
    return f"{minutes} min" if minutes < 120 else f"{minutes / 60:.1f} h"


# --------------------------------------------------------------------------- scoring engine
def _toks(text: str) -> list[str]:
    out = []
    for w in re.findall(r"[a-z0-9]+", (text or "").lower()):
        if w in STOP or len(w) < 2:
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.append(w)
    return out


class _BM25:
    def __init__(self, docs: list[list[str]], k1: float = 1.5, b: float = 0.75):
        self.docs, self.k1, self.b = docs, k1, b
        self.avg = sum(len(d) for d in docs) / len(docs)
        df: dict[str, int] = {}
        for d in docs:
            for t in set(d):
                df[t] = df.get(t, 0) + 1
        n = len(docs)
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}

    def score(self, q: list[str], i: int) -> tuple[float, list[str]]:
        d, tf = self.docs[i], {}
        for t in d:
            tf[t] = tf.get(t, 0) + 1
        s, hits = 0.0, []
        for t in set(q):
            if t in tf:
                f = tf[t]
                s += self.idf[t] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * len(d) / self.avg))
                hits.append((self.idf[t], t))
        return s, [t for _, t in sorted(hits, reverse=True)]


def _runbook_doc(rb: dict) -> list[str]:
    return _toks(rb["title"]) * 3 + _toks(rb["tags"]) * 3 + _toks(rb["steps_text"])


def _triage(inc: dict, runbooks: list[dict], history: list[dict], changes: list[dict]):
    """Rank runbooks for an incident. Returns (route, candidates, similar_past_incidents)."""
    q = _toks(inc["summary"]) * 2 + _toks(inc["description"]) + _toks(inc["service"].replace("-", " "))
    rb_idx = _BM25([_runbook_doc(r) for r in runbooks])
    h_idx = _BM25([_toks(h["summary"] + " " + (h["description"] or "")) for h in history])
    top3 = sorted(((h_idx.score(q, i)[0], i) for i in range(len(history))), reverse=True)[:3]
    best_sim = max((s for s, _ in top3), default=0.0)
    similar = [history[j] for s, j in top3 if s > 1.0 and s >= 0.5 * best_sim]
    cands = []
    for i, r in enumerate(runbooks):
        raw, hits = rb_idx.score(q, i)
        match = raw / (raw + K)
        used = [history[j] for s, j in top3 if s > 1.0 and history[j]["resolution_runbook"] == r["id"]]
        hist = len(used) / 3
        chg, chg_row = 0.0, None
        if r["addresses_change"]:
            for c in changes:
                if c["ci"] == inc["ci"]:
                    age = (inc["opened_at"] - c["deployed_at"]).total_seconds() / 60
                    v = 1.0 if 0 <= age <= 60 else 0.7 if 0 <= age <= 360 else 0.4 if 0 <= age <= 1440 else 0.0
                    if v > chg:
                        chg, chg_row = v, (c, round(age))
        svc = 1.0 if inc["service"] in r["services"] or inc["ci"] in r["services"] \
            else 0.5 if "*" in r["services"] else 0.0
        conf = W["match"] * match + W["history"] * hist + W["change"] * chg + W["service"] * svc
        gated = bool(r["addresses_change"]) and chg == 0
        if gated:                      # applicability gate: a rollback needs a recent change
            conf *= 0.5
        cands.append(dict(runbook=r, confidence=round(conf, 3), hits=hits[:4], history=used, change=chg_row,
                          gated=gated, parts=dict(match=match, history=hist, change=chg, service=svc)))
    cands.sort(key=lambda c: -c["confidence"])
    top = cands[0]
    if top["confidence"] < ESCALATE_BELOW:
        route = "ESCALATE"
    elif top["runbook"]["risk"] in ("MEDIUM", "HIGH"):
        route = "CHANGE_REQUEST"
    else:
        route = "DIRECT"
    return route, cands, similar


# --------------------------------------------------------------------------- tool implementations
def _list_incidents(status: Any, priority: Any, limit: Any) -> dict:
    status = str(status or "open").strip().lower()
    if status not in ("open", "resolved"):
        status = "open"
    pri = str(priority or "").strip().upper()
    pri = f"P{pri}" if pri in ("1", "2", "3", "4") else pri
    pri = pri if pri in PRIORITY_RANK else ""
    try:
        n = int(limit) if limit is not None else 5
    except (TypeError, ValueError):
        n = 5
    n = max(1, min(n, MAX_LIST))

    with _connect() as con:
        rows = _rows(con, "SELECT * FROM incidents WHERE status = ?", (status,))
    incs = []
    for r in rows:
        r["opened_at"] = datetime.fromisoformat(r["opened_at"])
        if not pri or r["priority"] == pri:
            incs.append(r)
    incs.sort(key=lambda r: (PRIORITY_RANK.get(r["priority"], 9), _sla_remaining(r)))
    shown = [dict(urgency_rank=i + 1, id=r["id"], summary=r["summary"], priority=r["priority"],
                  service=r["service"], age_minutes=_minutes(NOW - r["opened_at"]),
                  sla_minutes_remaining=_sla_remaining(r), sla_state=_sla_state(r))
             for i, r in enumerate(incs[:n])]
    if shown:
        top = shown[0]
        headline = (f"{len(incs)} {status} incident(s); most urgent is {top['id']} "
                    f"({top['priority']}, {top['service']}): {top['summary']}")
    else:
        headline = f"No {status} incidents found"
    return {"headline": headline, "as_of": NOW.isoformat(), "total_matching": len(incs),
            "sorted_by": "priority, then SLA minutes remaining (most urgent first)", "incidents": shown}


def _get_incident_details(incident_id: Any) -> dict:
    with _connect() as con:
        inc = _need_incident(con, incident_id)
        notes = _rows(con, "SELECT ts, author, note FROM work_notes WHERE incident_id = ? "
                           "ORDER BY ts DESC LIMIT 5", (inc["id"],))
        changes = _changes(con)
    recent = []
    for c in changes:
        mins = _minutes(inc["opened_at"] - c["deployed_at"])
        if c["ci"] == inc["ci"] and -60 <= mins <= 7 * 1440:
            recent.append(dict(id=c["id"], description=c["description"], type=c["change_type"],
                               minutes_before_incident=mins, within_24h=0 <= mins <= 1440))
    recent = recent[:5]
    out = {
        "headline": "",
        "incident": dict(id=inc["id"], summary=inc["summary"], description=inc["description"],
                         priority=inc["priority"], status=inc["status"], service=inc["service"],
                         affected_system=inc["ci"], owner_group=inc["owner_group"],
                         opened_at=inc["opened_at"].isoformat(),
                         age_minutes=_minutes(NOW - inc["opened_at"]),
                         sla_minutes_remaining=_sla_remaining(inc), sla_state=_sla_state(inc)),
        "work_notes": [dict(minutes_ago=_minutes(NOW - datetime.fromisoformat(n["ts"])),
                            author=n["author"], note=n["note"]) for n in notes],
        "recent_changes": recent,
    }
    if inc["status"] == "resolved":
        out["incident"]["resolution_notes"] = inc["resolution_notes"]
    recent24 = [c["id"] for c in recent if c["within_24h"]]
    out["headline"] = (f"{inc['id']} ({inc['priority']}, {inc['service']}): {inc['summary']}. "
                       f"{len(recent)} change(s) on {inc['ci']} in the last 7 days"
                       + (f", including {', '.join(recent24)} within 24h before the incident." if recent24 else "."))
    return out


def _evidence(inc: dict, top: dict, route: str) -> list[str]:
    rb, p = top["runbook"], top["parts"]
    if route == "ESCALATE":
        ev = [f"Best candidate {rb['id']} ({rb['title']}) scored only {top['confidence']:.2f}, "
              f"below the {ESCALATE_BELOW:.2f} threshold"]
        if not top["history"]:
            ev.append("No similar past incident was resolved with that runbook")
        if p["service"] == 0.0:
            ev.append(f"The runbook is written for other systems ({', '.join(rb['services'])})")
        if p["match"] < 0.5:
            ev.append(f"Little text overlap with this incident (match {p['match']:.2f})")
        return ev[:4]
    ev = []
    if top["change"]:
        c, age = top["change"]
        ev.append(f"{c['id']} ({c['description']}) hit {c['ci']} {_age_text(age)} before this incident")
    if top["history"]:
        ids = ", ".join(h["id"] for h in top["history"])
        ev.append(f"{len(top['history'])} of the 3 most similar past incidents were resolved with "
                  f"{rb['id']} ({ids})")
    if top["hits"]:
        ev.append(f"Runbook covers key terms: {', '.join(top['hits'])}")
    if p["service"] == 1.0:
        ev.append(f"Runbook is written for {inc['service']} / {inc['ci']}")
    elif p["service"] == 0.5:
        ev.append("Runbook is generic and applies to any service")
    return ev[:4]


def _suggest_remediation(incident_id: Any) -> dict:
    with _connect() as con:
        inc = _need_incident(con, incident_id)
        if inc["status"] != "open":
            raise _ToolError(f"{inc['id']} is {inc['status']}, not open. "
                             f"Its resolution: {inc['resolution_notes'] or 'none recorded'}")
        history, changes = _history(con), _changes(con)
    route, cands, similar = _triage(inc, _runbooks(), history, changes)
    top = cands[0]
    rb = top["runbook"]
    evidence = _evidence(inc, top, route)
    conf = round(top["confidence"], 2)
    parts = {k: round(v, 2) for k, v in top["parts"].items()}
    parts["applicability_gate_applied"] = top["gated"]

    alternatives = []
    for c in cands[1:]:
        if c["confidence"] >= 0.25 and c["confidence"] >= 0.4 * top["confidence"] and len(alternatives) < 2:
            alt = dict(runbook_id=c["runbook"]["id"], title=c["runbook"]["title"],
                       confidence=round(c["confidence"], 2))
            if c["gated"]:
                alt["note"] = "applies only after a recent change, and none was found"
            alternatives.append(alt)

    caveats = []
    if top["gated"]:
        caveats.append(f"No change found on {inc['ci']} in the last 24h, so a rollback may not apply")
    for alt in alternatives:
        if alt.get("note"):
            caveats.append(f"{alt['runbook_id']} was considered but no change was found on {inc['ci']} "
                           f"in the last 24h, so a rollback is not recommended")
    if len(cands) > 1 and top["confidence"] - cands[1]["confidence"] < 0.05:
        caveats.append(f"Close call between {rb['id']} and {cands[1]['runbook']['id']}")
    if route == "CHANGE_REQUEST" and top["confidence"] < 0.5:
        caveats.append("Moderate confidence - the approver should review the evidence before approving")

    out: dict[str, Any] = {"incident_id": inc["id"], "headline": "", "route": route, "confidence": conf,
                           "breakdown": parts, "evidence": evidence, "alternatives": alternatives,
                           "caveats": caveats}
    if route == "ESCALATE":
        out["headline"] = (f"ESCALATE to {inc['owner_group']}: no runbook reached confidence "
                           f"{ESCALATE_BELOW:.2f} (best was {rb['id']} at {conf:.2f}).")
        out["runbook"] = None
        out["next_action"] = (f"Escalate to {inc['owner_group']} with the context below. "
                              "No runbook matched with enough confidence")
        out["context_for_escalation"] = {
            "owner_group": inc["owner_group"],
            "best_candidate": dict(runbook_id=rb["id"], title=rb["title"], confidence=conf),
            "recent_changes": [dict(id=c["id"], ci=c["ci"], description=c["description"],
                                    days_before_incident=round((inc["opened_at"] - c["deployed_at"]).total_seconds() / 86400, 1))
                               for c in changes if c["ci"] == inc["ci"]
                               and 0 <= (inc["opened_at"] - c["deployed_at"]).total_seconds() <= 7 * 86400][:3],
            "similar_past_incidents": [dict(id=h["id"], summary=h["summary"],
                                            resolution_notes=h["resolution_notes"]) for h in similar[:3]],
        }
        out["change_request_draft"] = None
        return out

    steps = [dict(n=i + 1, text=s["text"], risk=s["risk"], reversible=s["reversible"], minutes=s["minutes"])
             for i, s in enumerate(rb["steps"][:8])]
    out["runbook"] = dict(id=rb["id"], title=rb["title"], risk=rb["risk"], rollback=rb["rollback"], steps=steps)
    lead = evidence[0] if evidence else "closest runbook match"
    out["headline"] = f"{route} at confidence {conf:.2f}: {rb['title']} ({rb['id']}). {lead}."
    if route == "DIRECT":
        out["next_action"] = "Follow the runbook steps. No change request is needed because the risk is low"
        out["change_request_draft"] = None
    else:
        out["next_action"] = (f"Raise a change request. Suggested approver is the {APPROVER}. "
                              "The draft below is NOT submitted")
        out["change_request_draft"] = dict(
            status="NOT_SUBMITTED", incident_id=inc["id"], runbook_id=rb["id"], risk=rb["risk"],
            proposed_approver=APPROVER,
            justification=(f"Incident {inc['id']} ({inc['priority']}, {inc['service']}): {inc['summary']}. "
                           f"Evidence: {'; '.join(evidence[:3])}. Proposed fix: {rb['title']} ({rb['id']})."),
            steps=[s["text"] for s in rb["steps"][:8]], rollback_plan=rb["rollback"])
    return out


def _health() -> dict:
    try:
        with _connect() as con:
            n_open = con.execute("SELECT COUNT(*) FROM incidents WHERE status = 'open'").fetchone()[0]
            n_hist = con.execute("SELECT COUNT(*) FROM incidents WHERE status = 'resolved'").fetchone()[0]
        n_rb = len(_runbooks())
        return {"status": "healthy", "service": "incident_mcp", "open_incidents": n_open,
                "resolved_incidents": n_hist, "runbooks": n_rb}
    except Exception as exc:
        return {"status": "degraded", "service": "incident_mcp", "error": str(exc)}


def _run(tool: str, args: dict, fn, *fn_args) -> dict:
    """Run a tool implementation: audit it and always return a dict (errors as data)."""
    started, status = time.time(), "ok"
    try:
        return fn(*fn_args)
    except _ToolError as exc:
        status = "error"
        return {"error": str(exc)}
    except sqlite3.Error as exc:
        status = "error"
        return {"error": f"Incident data is unavailable ({exc}). Check that the data folder is mounted."}
    except Exception as exc:  # never let an unexpected problem crash the tool server
        status = f"error: {type(exc).__name__}"
        logger.error(f"{tool} failed: {exc}")
        return {"error": f"Unexpected error in {tool}: {exc}"}
    finally:
        _audit(tool, args, status, started)


# --------------------------------------------------------------------------- the KAF tool class
class Incident:
    def __init__(self) -> None:
        logger.info("Initializing Incident triage tools")
        logger.success("Incident initialized")

    def health_check(self) -> dict[str, Any]:
        """
        description:
            Check the health of the incident triage tools. Returns status and the number of
            incidents and runbooks that are loaded.

        expose:
            - mcp
            - fastapi

        tags:
            - health
            - status
        """
        return _health()

    def list_incidents(self, status: str | None = "open", priority: str | None = None,
                       limit: int | None = 5) -> dict[str, Any]:
        """
        description:
            List IT incidents in the service desk queue, sorted most urgent first by priority and
            then SLA minutes remaining. Each incident has an urgency_rank (1 is most urgent), its
            priority, affected service, age in minutes and SLA minutes remaining. Call this first to
            find the incident ids that the other incident tools require.

        expose:
            - mcp
            - fastapi

        tags:
            - incident
            - itsm
            - queue

        args:
            status:
                description: Incident status to list, open or resolved (default open)
                required: false
            priority:
                description: Optional priority filter P1, P2, P3 or P4
                required: false
            limit:
                description: Maximum number of incidents to return (default 5, maximum 20)
                required: false
        """
        return _run("list_incidents", {"status": status, "priority": priority, "limit": limit},
                    _list_incidents, status, priority, limit)

    def get_incident_details(self, incident_id: str) -> dict[str, Any]:
        """
        description:
            Get the full context of one incident, including its description, recent work notes,
            affected system, owning support group, and the changes made on that system in the last
            7 days. Use this to understand what happened before recommending a fix.

        expose:
            - mcp
            - fastapi

        tags:
            - incident
            - itsm
            - context

        args:
            incident_id:
                description: Incident id as returned by list_incidents, for example INC0101
                required: true
        """
        return _run("get_incident_details", {"incident_id": incident_id},
                    _get_incident_details, incident_id)

    def suggest_remediation(self, incident_id: str) -> dict[str, Any]:
        """
        description:
            Recommend how to resolve an open incident. Returns a one sentence headline, the best
            matching runbook with its steps, a confidence score with evidence, alternatives, and a
            route of DIRECT (low risk steps), CHANGE_REQUEST (a drafted, unsubmitted change request
            for human approval) or ESCALATE (no confident match, with context for the owning
            group). Advisory only and it never makes changes.

        expose:
            - mcp
            - fastapi

        tags:
            - incident
            - triage
            - runbook

        args:
            incident_id:
                description: Incident id as returned by list_incidents, for example INC0101
                required: true
        """
        return _run("suggest_remediation", {"incident_id": incident_id},
                    _suggest_remediation, incident_id)
