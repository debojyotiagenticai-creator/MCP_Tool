"""Build the demo data for the incident triage tool (standard library only).

    python3 seed/seed.py            -> writes ../data/incident.db and ../data/runbooks/*.json

All times are relative to one fixed demo clock (NOW) so the demo never drifts.
NOW must match NOW in src/incident.py (a test enforces this).
Do not reword the incident, history or runbook text casually: the confidence scores
were verified against exactly this wording.
"""
from __future__ import annotations

import json
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

NOW = datetime(2026, 3, 14, 2, 10)


def ago(**kw) -> str:
    return (NOW - timedelta(**kw)).isoformat()


SCHEMA = """
CREATE TABLE incidents(
    id TEXT PRIMARY KEY, summary TEXT, description TEXT, priority TEXT, status TEXT,
    service TEXT, ci TEXT, owner_group TEXT, opened_at TEXT, resolved_at TEXT,
    resolution_notes TEXT, resolution_runbook TEXT);
CREATE TABLE work_notes(
    id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT, ts TEXT, author TEXT, note TEXT);
CREATE TABLE changes(
    id TEXT PRIMARY KEY, ci TEXT, service TEXT, description TEXT, deployed_at TEXT, change_type TEXT);
"""

# id, priority, service, ci, opened_at, summary, description, owner_group
OPEN_INCIDENTS = [
    ("INC0101", "P1", "checkout-api", "payment-gateway-prod", ago(minutes=5),
     "Checkout API returning HTTP 5xx errors",
     "Error rate on the checkout API jumped to 38 percent. Customers see failed payments. "
     "Started shortly after the last release.", "Payments Platform"),
    ("INC0102", "P3", "log-platform", "app-log-02", ago(hours=3),
     "Disk usage 95 percent on log server",
     "Filesystem var log at 95 percent on app-log-02. Growing steadily over the last days.",
     "Linux Operations"),
    ("INC0103", "P2", "order-events", "kafka-prod-01", ago(minutes=50),
     "Kafka consumer lag growing on order-events topic",
     "Consumer group order-processor lag exceeds 200000 messages and is rising. Orders are delayed.",
     "Messaging Platform"),
    ("INC0104", "P2", "orders-db", "orders-db-01", ago(hours=1),
     "Slow database queries on orders database",
     "Query latency high and application timeouts. Connection count near the limit.",
     "Database Operations"),
    ("INC0105", "P3", "customer-portal", "portal-web-01", ago(hours=6),
     "TLS certificate expires in 5 days on customer portal",
     "Monitoring warns the https certificate for the customer portal is expiring soon.",
     "Web Operations"),
    ("INC0106", "P4", "vpn", "vpn-gw-01", ago(hours=8),
     "Intermittent login timeouts on VPN",
     "Some remote users report login timeouts on the VPN gateway during the morning.",
     "Network Operations"),
    ("INC0107", "P2", "batch-scheduler", "batch-01", ago(minutes=30),
     "Nightly batch job hung and not completing",
     "The reconciliation batch job has been stuck for two hours and is not completing.",
     "Batch Operations"),
    ("INC0108", "P3", "checkout-api", "checkout-web-01", ago(minutes=20),
     "Checkout page slow to load for some users",
     "Page load time is high on the checkout page. No errors reported. No recent release.",
     "Web Operations"),
]

# Resolved history: the phrase goes in summary (description empty) - this is what was verified.
# id, summary, resolution_runbook, resolution_notes, opened days ago
RESOLVED = [
    ("INC0090", "Disk usage 92 percent on app-log-02 filesystem var log growing", "RB-002",
     "Rotated and compressed logs older than 14 days; logrotate set to daily.", 20),
    ("INC0091", "Filesystem full on log server app-log-03 logs not rotated", "RB-002",
     "Cleaned old logs and fixed the missing logrotate entry.", 34),
    ("INC0092", "Log volume nearly full on app-log-01 disk space", "RB-002",
     "Freed 40 GB by compressing archived logs.", 48),
    ("INC0093", "Checkout API 5xx errors after release failed payments", "RB-001",
     "Rolled back release 2.12.3; error rate returned to normal.", 27),
    ("INC0094", "Payment errors spike after deployment error rate", "RB-001",
     "Rolled back the deployment; the fix shipped the next day.", 41),
    ("INC0095", "Kafka consumer lag on payments topic restarted consumers manually", None,
     "Restarted the consumer group manually. No runbook exists for consumer lag.", 16),
    ("INC0096", "TLS certificate expiry warning https portal", "RB-006",
     "Renewed the certificate and reloaded the web server.", 60),
    ("INC0097", "Application timeouts connection pool exhausted slow queries", "RB-004",
     "Killed blocking sessions and raised the pool size.", 33),
    ("INC0098", "Batch job stuck not completing process hung", "RB-003",
     "Restarted the batch process after capturing a thread dump.", 22),
]

# id, ci, service, description, deployed_at, change_type
CHANGES = [
    ("CHG-017", "payment-gateway-prod", "checkout-api", "Deploy payment-gateway release 2.14.0",
     ago(minutes=40), "deployment"),
    ("CHG-011", "kafka-prod-01", "order-events", "Broker config tuning", ago(days=5), "config"),
    ("CHG-014", "app-log-02", "log-platform", "OS patching", ago(days=12), "patch"),
    ("CHG-009", "orders-db-01", "orders-db", "Index maintenance", ago(days=3), "maintenance"),
    ("CHG-021", "lb-prod-01", "edge", "Load balancer certificate refresh", ago(days=6), "config"),
    ("CHG-022", "san-02", "storage", "Storage firmware update", ago(days=9), "patch"),
]

# incident_id -> [(minutes_ago, author, note)]   (display only, never scored)
WORK_NOTES = {
    "INC0101": [(5, "monitoring", "Alert: checkout API 5xx rate above 30 percent for 3 minutes."),
                (4, "L1 analyst", "Confirmed errors on the pay endpoint. Paging payments on-call."),
                (2, "L1 analyst", "Customer contact center reports failed card payments.")],
    "INC0102": [(180, "monitoring", "Alert: /var/log above 90 percent on app-log-02."),
                (120, "L1 analyst", "Growth is steady, no sign of a runaway process.")],
    "INC0103": [(50, "monitoring", "Alert: consumer lag above threshold for order-processor."),
                (35, "L1 analyst", "Consumers are running but processing slowly.")],
    "INC0104": [(60, "monitoring", "Alert: p95 query latency above 2 seconds."),
                (40, "L1 analyst", "Application teams report timeouts on order lookups.")],
    "INC0105": [(360, "monitoring", "Alert: certificate expires in 5 days on customer portal.")],
    "INC0106": [(480, "L1 analyst", "Three users reported VPN login timeouts this morning."),
                (300, "L1 analyst", "Cannot reproduce from the office network.")],
    "INC0107": [(30, "monitoring", "Alert: batch job exceeded its expected runtime."),
                (15, "L1 analyst", "Job process is alive but producing no output.")],
    "INC0108": [(20, "monitoring", "Alert: checkout page load time above 4 seconds."),
                (10, "L1 analyst", "No errors in the logs, only slow responses.")],
}

# Runbooks. Step wording is indexed by the search - keep it as written.
RUNBOOKS = [
    dict(id="RB-001", title="Roll back a faulty application release",
         services=["checkout-api", "payment-gateway-prod", "*"], risk="MEDIUM", addresses_change=True,
         tags="5xx error rate deploy deployment release rollback regression failed payments",
         rollback="Redeploy the faulty release tag once a fix is available",
         steps=[("Confirm deploy time", "LOW", True, 2),
                ("Compare error rate before and after", "LOW", True, 3),
                ("Roll back to previous release tag", "MEDIUM", True, 10),
                ("Verify error rate", "LOW", True, 5),
                ("Notify stakeholders", "LOW", True, 2)]),
    dict(id="RB-002", title="Free disk space by rotating and cleaning logs",
         services=["*"], risk="LOW", addresses_change=False,
         tags="disk filesystem full space logs log rotation var log capacity",
         rollback="Not needed: only old compressed logs are removed",
         steps=[("Find largest directories with du", "LOW", True, 3),
                ("Check logrotate config", "LOW", True, 3),
                ("Compress or delete logs older than 14 days", "LOW", False, 10),
                ("Verify free space", "LOW", True, 2)]),
    dict(id="RB-003", title="Restart a hung application process",
         services=["*"], risk="MEDIUM", addresses_change=False,
         tags="hung unresponsive stuck restart process job batch not completing",
         rollback="Start the process again from the last good state",
         steps=[("Confirm process is hung", "LOW", True, 3),
                ("Capture thread dump", "LOW", True, 3),
                ("Restart service", "MEDIUM", True, 5),
                ("Verify health", "LOW", True, 3)]),
    dict(id="RB-004", title="Resolve database connection pool exhaustion",
         services=["orders-db", "checkout-api"], risk="MEDIUM", addresses_change=False,
         tags="database connections pool timeout slow queries latency saturated",
         rollback="Restore the previous pool size setting",
         steps=[("Check active connections", "LOW", True, 3),
                ("Identify long running queries", "LOW", True, 5),
                ("Kill blocking sessions", "MEDIUM", False, 5),
                ("Raise pool size", "MEDIUM", True, 5),
                ("Verify latency", "LOW", True, 3)]),
    dict(id="RB-005", title="Drain a stuck RabbitMQ message queue",
         services=["order-events-mq"], risk="MEDIUM", addresses_change=False,
         tags="queue backlog rabbitmq messages stuck drain consumer",
         rollback="Re-publish purged messages from the dead letter archive",
         steps=[("Inspect queue depth", "LOW", True, 3),
                ("Check consumers", "LOW", True, 3),
                ("Purge poison messages", "MEDIUM", False, 5),
                ("Restart consumer", "MEDIUM", True, 5),
                ("Verify backlog clears", "LOW", True, 5)]),
    dict(id="RB-006", title="Renew an expiring TLS certificate",
         services=["*"], risk="MEDIUM", addresses_change=False,
         tags="certificate tls ssl expiry expiring https renew",
         rollback="Reinstall the previous certificate",
         steps=[("Confirm expiry date", "LOW", True, 2),
                ("Generate csr", "LOW", True, 5),
                ("Install new certificate", "MEDIUM", True, 10),
                ("Reload web server", "MEDIUM", True, 3),
                ("Verify chain", "LOW", True, 3)]),
]


def build(data_dir: Path) -> dict:
    data_dir = Path(data_dir)
    (data_dir / "runbooks").mkdir(parents=True, exist_ok=True)
    for old in (data_dir / "runbooks").glob("*.json"):
        old.unlink()
    db_path = data_dir / "incident.db"
    if db_path.exists():
        db_path.unlink()

    con = sqlite3.connect(db_path)
    con.executescript(SCHEMA)
    for (iid, pri, svc, ci, opened, summary, desc, owner) in OPEN_INCIDENTS:
        con.execute("INSERT INTO incidents VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (iid, summary, desc, pri, "open", svc, ci, owner, opened, None, None, None))
    for (iid, summary, rb, notes, days) in RESOLVED:
        con.execute("INSERT INTO incidents VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (iid, summary, "", "P3", "resolved", "n/a", "n/a", "n/a",
                     ago(days=days), ago(days=days - 1), notes, rb))
    for row in CHANGES:
        con.execute("INSERT INTO changes VALUES (?,?,?,?,?,?)", row)
    for iid, notes in WORK_NOTES.items():
        for (mins, author, note) in notes:
            con.execute("INSERT INTO work_notes(incident_id, ts, author, note) VALUES (?,?,?,?)",
                        (iid, ago(minutes=mins), author, note))
    con.commit()
    con.close()

    for rb in RUNBOOKS:
        doc = dict(rb)
        doc["steps"] = [dict(text=t, risk=r, reversible=rev, minutes=m) for (t, r, rev, m) in rb["steps"]]
        (data_dir / "runbooks" / f"{rb['id']}.json").write_text(json.dumps(doc, indent=2) + "\n")
    return dict(open=len(OPEN_INCIDENTS), resolved=len(RESOLVED), changes=len(CHANGES),
                runbooks=len(RUNBOOKS), path=str(db_path))


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "data"
    info = build(target)
    print(f"Seeded {info['path']}: {info['open']} open + {info['resolved']} resolved incidents, "
          f"{info['changes']} changes, {info['runbooks']} runbooks")
