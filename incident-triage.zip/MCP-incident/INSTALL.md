# Incident triage tool - install on the KAF VM

Run as labuser from ~/Bootcamp-LocalDeployment (never as root).

1. Copy these into the scaffolded repo MCP-incident (it already exists):
     src/incident.py          -> MCP-incident/src/incident.py        (replaces the stub)
     seed/seed.py             -> MCP-incident/seed/seed.py           (new folder)
     tests/test_scenarios.py  -> MCP-incident/tests/test_scenarios.py
     data/                    -> MCP-incident/data/                  (incident.db + runbooks/)
2. Rebuild the data (optional, it is already included):  python3 MCP-incident/seed/seed.py
3. Test:   cd MCP-incident && uv run pytest tests -q          (expect 36 passed + the 2 scaffold tests)
4. Rebuild the image and restart (code is baked into the image):
     cd ~/Bootcamp-LocalDeployment && ./stop-kaf.sh
     docker rm -f incident-mcp 2>/dev/null; docker rmi bootcamp-localdeployment-incident-mcp
     ./start-kaf.sh -t incident-dev
5. Verify:  docker exec incident-mcp grep -c "_suggest_remediation" /app/incident.py   (expect 2 or more)
            docker exec incident-mcp ls /data/incident /data/incident/runbooks
