"""Acceptance tests for the incident triage tools.

The data is seeded into a temporary folder, so these tests never touch your real data/.
Run from the repo folder:   uv run pytest tests -q
"""
from __future__ import annotations

import importlib.util
import inspect
import json
import os
import sqlite3
import sys
import tempfile
import textwrap
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

_spec = importlib.util.spec_from_file_location("incident_seed", ROOT / "seed" / "seed.py")
seed_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(seed_mod)

_TMP = Path(tempfile.mkdtemp(prefix="incident-test-"))
seed_mod.build(_TMP)
os.environ["INCIDENT_DATA_DIR"] = str(_TMP)
os.environ["AUDIT_LOG"] = str(_TMP / "audit.log")

import incident  # noqa: E402  (must import after the environment is set)

TOOL = incident.Incident()

# incident -> (route, confidence, runbook). Confidence tolerance is 0.02.
SCENARIOS = {
    "INC0101": ("CHANGE_REQUEST", 0.79, "RB-001"),   # checkout 5xx after a deploy
    "INC0102": ("DIRECT", 0.62, "RB-002"),           # disk 95 percent
    "INC0103": ("ESCALATE", 0.20, "RB-005"),         # Kafka lag, no runbook (RB-005 is the weak best guess)
    "INC0104": ("CHANGE_REQUEST", 0.50, "RB-004"),   # slow database
    "INC0105": ("CHANGE_REQUEST", 0.42, "RB-006"),   # TLS expiry
    "INC0106": ("ESCALATE", 0.22, "RB-004"),         # VPN timeouts, no runbook
    "INC0107": ("CHANGE_REQUEST", 0.42, "RB-003"),   # batch job hung
    "INC0108": ("ESCALATE", 0.32, "RB-004"),         # decoy: slow page, no recent release
}


def best_runbook(resp: dict) -> str:
    if resp["route"] == "ESCALATE":
        return resp["context_for_escalation"]["best_candidate"]["runbook_id"]
    return resp["runbook"]["id"]


# --------------------------------------------------------------------------- data and clock
def test_seed_counts():
    con = sqlite3.connect(_TMP / "incident.db")
    assert dict(con.execute("SELECT status, COUNT(*) FROM incidents GROUP BY 1")) == {"open": 8, "resolved": 9}
    assert len(list((_TMP / "runbooks").glob("*.json"))) == 6


def test_clock_matches_seed():
    assert incident.NOW == seed_mod.NOW


def test_health_check_healthy():
    h = TOOL.health_check()
    assert h["status"] == "healthy" and h["open_incidents"] == 8 and h["runbooks"] == 6


# --------------------------------------------------------------------------- scenario table
@pytest.mark.parametrize("iid", sorted(SCENARIOS))
def test_scenario_routes(iid):
    route, conf, rb = SCENARIOS[iid]
    r = TOOL.suggest_remediation(iid)
    assert r["route"] == route
    assert abs(r["confidence"] - conf) <= 0.02
    assert best_runbook(r) == rb
    json.dumps(r)                                    # must be JSON serialisable


def test_checkout_change_request_story():
    r = TOOL.suggest_remediation("INC0101")
    assert r["headline"].startswith("CHANGE_REQUEST")
    assert any("CHG-017" in e for e in r["evidence"])
    draft = r["change_request_draft"]
    assert draft["status"] == "NOT_SUBMITTED"
    assert draft["runbook_id"] == "RB-001" and draft["rollback_plan"]
    assert draft["steps"] == [s["text"] for s in r["runbook"]["steps"]]
    assert draft["proposed_approver"] == "Duty Manager"
    assert "NOT submitted" in r["next_action"]


def test_disk_is_direct_without_change_request():
    r = TOOL.suggest_remediation("INC0102")
    assert r["route"] == "DIRECT" and r["change_request_draft"] is None
    assert r["runbook"]["risk"] == "LOW" and len(r["runbook"]["steps"]) == 4


def test_kafka_escalates_with_context():
    r = TOOL.suggest_remediation("INC0103")
    assert r["route"] == "ESCALATE" and r["runbook"] is None and r["change_request_draft"] is None
    assert "Messaging Platform" in r["next_action"]
    ctx = r["context_for_escalation"]
    assert ctx["owner_group"] == "Messaging Platform"
    assert [h["id"] for h in ctx["similar_past_incidents"]] == ["INC0095"]
    assert [c["id"] for c in ctx["recent_changes"]] == ["CHG-011"]


def test_decoy_does_not_recommend_rollback():
    r = TOOL.suggest_remediation("INC0108")
    assert r["route"] == "ESCALATE" and r["runbook"] is None
    assert any("RB-001" in c and "no change was found" in c for c in r["caveats"])
    assert all(a["runbook_id"] != "RB-001" or a.get("note") for a in r["alternatives"])


def test_rollback_runbook_is_gated_without_recent_change():
    r = TOOL.suggest_remediation("INC0108")
    rb001 = [a for a in r["alternatives"] if a["runbook_id"] == "RB-001"]
    assert rb001 and "recent change" in rb001[0]["note"]


def test_every_response_is_small():
    for iid in SCENARIOS:
        assert len(json.dumps(TOOL.suggest_remediation(iid))) < 4000, iid
        assert len(json.dumps(TOOL.get_incident_details(iid))) < 4000, iid
    assert len(json.dumps(TOOL.list_incidents(limit=20))) < 5000


def test_results_are_deterministic():
    assert TOOL.suggest_remediation("INC0101") == TOOL.suggest_remediation("INC0101")


# --------------------------------------------------------------------------- list_incidents
def test_list_is_sorted_most_urgent_first():
    r = TOOL.list_incidents(limit=20)
    ids = [i["id"] for i in r["incidents"]]
    assert ids[0] == "INC0101" and r["total_matching"] == 8 and len(ids) == 8
    assert [i["urgency_rank"] for i in r["incidents"]] == list(range(1, 9))
    keys = [(int(i["priority"][1]), i["sla_minutes_remaining"]) for i in r["incidents"]]
    assert keys == sorted(keys)
    assert r["incidents"][0]["sla_minutes_remaining"] == 55
    assert r["headline"].startswith("8 open incident(s); most urgent is INC0101")


def test_list_accepts_nulls_and_defaults():
    r = TOOL.list_incidents(status=None, priority=None, limit=None)
    assert len(r["incidents"]) == 5            # default limit
    assert r == TOOL.list_incidents()          # same as no arguments


def test_list_normalises_inputs():
    assert {i["priority"] for i in TOOL.list_incidents(priority="p2", limit=20)["incidents"]} == {"P2"}
    assert {i["priority"] for i in TOOL.list_incidents(priority="2", limit=20)["incidents"]} == {"P2"}
    assert len(TOOL.list_incidents(limit=0)["incidents"]) == 1            # clamped up to 1
    assert len(TOOL.list_incidents(limit=500)["incidents"]) == 8          # clamped to the maximum
    assert len(TOOL.list_incidents(limit="3")["incidents"]) == 3          # numeric string accepted
    assert TOOL.list_incidents(status="OPEN")["total_matching"] == 8
    assert TOOL.list_incidents(status="nonsense")["total_matching"] == 8  # unknown falls back to open
    assert TOOL.list_incidents(priority="P9", limit=20)["total_matching"] == 8   # bad filter ignored


def test_list_resolved():
    r = TOOL.list_incidents(status="resolved", limit=20)
    assert r["total_matching"] == 9


# --------------------------------------------------------------------------- get_incident_details
def test_details_with_recent_change():
    r = TOOL.get_incident_details("INC0101")
    assert r["incident"]["owner_group"] == "Payments Platform"
    assert r["incident"]["affected_system"] == "payment-gateway-prod"
    assert r["recent_changes"][0]["id"] == "CHG-017" and r["recent_changes"][0]["within_24h"] is True
    assert r["recent_changes"][0]["minutes_before_incident"] == 35
    assert "CHG-017" in r["headline"]
    notes = r["work_notes"]
    assert 1 <= len(notes) <= 5 and notes[0]["minutes_ago"] <= notes[-1]["minutes_ago"]   # newest first


def test_details_change_window():
    assert TOOL.get_incident_details("INC0102")["recent_changes"] == []      # CHG-014 is 12 days old
    kafka = TOOL.get_incident_details("INC0103")["recent_changes"]
    assert [c["id"] for c in kafka] == ["CHG-011"] and kafka[0]["within_24h"] is False


def test_details_normalises_the_id():
    assert TOOL.get_incident_details("  inc0101 ")["incident"]["id"] == "INC0101"


def test_details_of_resolved_incident_include_resolution():
    r = TOOL.get_incident_details("INC0095")
    assert r["incident"]["status"] == "resolved" and "consumer group" in r["incident"]["resolution_notes"]


# --------------------------------------------------------------------------- errors are data
def test_unknown_and_missing_ids():
    for bad in ("INC9999", "", None, "   "):
        for fn in (TOOL.get_incident_details, TOOL.suggest_remediation):
            r = fn(bad)
            assert "error" in r and "INC0101" in r["error"], (fn.__name__, bad)


def test_suggest_rejects_resolved_incident():
    r = TOOL.suggest_remediation("INC0090")
    assert "error" in r and "resolved" in r["error"] and "Rotated" in r["error"]


def test_missing_data_returns_error_not_crash(monkeypatch):
    monkeypatch.setenv("INCIDENT_DATA_DIR", str(_TMP / "does-not-exist"))
    for r in (TOOL.list_incidents(), TOOL.get_incident_details("INC0101"), TOOL.suggest_remediation("INC0101")):
        assert "error" in r and "seed" in r["error"]
    assert TOOL.health_check()["status"] == "degraded"


# --------------------------------------------------------------------------- safety
def test_database_is_read_only():
    con = incident._connect()
    with pytest.raises(sqlite3.OperationalError):
        con.execute("INSERT INTO changes VALUES ('X','a','b','c','2026-01-01T00:00:00','d')")
    con.close()


def test_audit_log_records_calls():
    log = Path(os.environ["AUDIT_LOG"])
    log.write_text("")
    TOOL.suggest_remediation("INC0101")
    TOOL.get_incident_details("INC9999")
    lines = [json.loads(x) for x in log.read_text().splitlines()]
    assert [(r["tool"], r["status"]) for r in lines] == [("suggest_remediation", "ok"),
                                                         ("get_incident_details", "error")]


def test_unwritable_audit_log_never_breaks_a_tool(monkeypatch):
    monkeypatch.setenv("AUDIT_LOG", "/proc/definitely/not/writable.log")
    assert TOOL.suggest_remediation("INC0101")["route"] == "CHANGE_REQUEST"


# --------------------------------------------------------------------------- KAF metadata
PUBLIC = {"health_check", "list_incidents", "get_incident_details", "suggest_remediation"}


def test_only_the_expected_public_methods():
    public = {n for n, _ in inspect.getmembers(incident.Incident, inspect.isfunction) if not n.startswith("_")}
    assert public == PUBLIC


def test_docstring_metadata_is_valid_yaml_and_matches_signatures():
    yaml = pytest.importorskip("yaml")
    for name in PUBLIC:
        fn = getattr(incident.Incident, name)
        meta = yaml.safe_load(textwrap.dedent(fn.__doc__))
        assert isinstance(meta["description"], str) and "mcp" in meta["expose"] and meta["tags"], name
        params = [p for p in inspect.signature(fn).parameters if p != "self"]
        assert set(params) == set(meta.get("args") or {}), name


def test_no_colon_space_inside_descriptions():
    """A ': ' inside a description line breaks KAF's YAML-style metadata parsing."""
    for name in PUBLIC:
        doc = getattr(incident.Incident, name).__doc__
        lines = doc.split("description:", 1)[1].split("expose:", 1)[0].splitlines()
        assert not any(": " in ln for ln in lines), name


def test_optional_parameters_accept_null():
    """KAF's agent sends explicit nulls for optional arguments it does not fill."""
    sig = inspect.signature(incident.Incident.list_incidents)
    for pname in ("status", "priority", "limit"):
        assert "None" in str(sig.parameters[pname].annotation), pname
